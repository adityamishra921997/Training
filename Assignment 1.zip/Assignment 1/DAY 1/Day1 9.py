li=[4,7,9]
for i in li:
    for j in range(0,i):
        print("*",end="")
    print("\n")
