n=int(input('enter the elements of list'))
l=[]
for i in range(0,n) :
    l.append(input(''))
x=input('enter the number to be searched')    
flag=0
for i in l :
    if (i==x):
        print('True')
        flag=1
        break
if flag==0 :
    print('False')

