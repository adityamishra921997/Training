name=input("enter the string")
output= name.swapcase()
print(output)
