firstname=input('enter the first name :')
lastname=input('enter the last name :')
wholename= firstname + '.' +lastname
print(wholename)
