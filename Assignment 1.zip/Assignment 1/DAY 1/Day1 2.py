a=int(input('enter the first number'))
b=int(input('enter the second number'))
c=a+b
if c>0 :
    print('Number is positive')
else :
    print('Number is negative')
