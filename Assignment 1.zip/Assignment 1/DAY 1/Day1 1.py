name=input('ENTER NAME :')
print('Hello', name)


