n=int(input('enter the element'))
l1=[]
for i in range(0,n):
    l1.append(input(''))
m=int(input('enter the element'))
l2=[]
for i in range (0,m) :
    l2.append(input(''))
f=0
for i in l1 :
    for j in l2 :
        if(i==j) :
            print('True')
            f=1
            break
if f==0 :
    print('False')
