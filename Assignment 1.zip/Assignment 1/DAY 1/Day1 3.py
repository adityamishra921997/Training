num=10;
inp=int(input('Enter Number'))
while  inp!=num :
    inp=int(input('Enter Number'))
print('Correct')
