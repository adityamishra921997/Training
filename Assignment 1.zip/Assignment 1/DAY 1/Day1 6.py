list=[1,2,3,4]
output=sum(list)
print(output)
product=1
for i in list:
    product=product*i
print(product)
