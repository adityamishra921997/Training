file=open('adi.txt','r')
text=file.read()
file.close
file1=open('adim.txt','w')
file1.write(text)
file1.close()
