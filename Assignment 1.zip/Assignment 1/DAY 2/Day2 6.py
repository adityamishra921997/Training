import re
st=input("Enter a string :")
st=re.sub(r"[^\w\s]","",st)
st=st.replace(" ","")
st=st.lower()
flag=1
l=len(st)
for i in range(l//2):
    if(st[i]!=st[l-1]):
        flag=0
        break
    l=l-1
if flag==1:
    print ("Palindrome")
else:
    print ("Not Palindrome")
