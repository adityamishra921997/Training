def Add(l1,l2):
    l3=[]
    if len(l1)>len(l2):
        l3=list(l1)
    else:
        l3=list(l2)
    a=len(l1)
    b=len(l2)
    if a>b:
        a=b
    for i in range(a):
        l3[i]=l1[i]+l2[i]
    return l3

def Sub(l1,l2):
    l3=[]
    if len(l1)>len(l2):
        l3=list(l1)
    else:
        l3=list(l2)
    a=len(l1)
    b=len(l2)
    if a>b:
        a=b
    for i in range(a):
        l3[i]=l1[i]-l2[i]
    return l3

def Sort_the_values(l1):
    l1.sort()
    return l1
def Max(l1):
    return max(l1)
