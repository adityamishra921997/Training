from math import *

print("Math:\n\nFactorial(100) :{0}\nSquare Root(9801): {1}\nSin(90) : {2}".format(factorial(100),sqrt(9801),sin(90)))
