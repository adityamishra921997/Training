n=int(input('enter the size of list'))
l1=[]
l2=[]
for i in range(0,n)
    l1.append (input(''))
    l2.append (input(len(l1[i])))
maxlen= lamda l:max(l)
m=maxlen(l2)
print(m)
