a=int(input('enter the size of list'))
l=[]

for i in range(0,a):
    b=input('enter the elements of list')
    l.append (b)
def maxnum(l):
    num=max(l)
    print(num)
maxnum(l)
    
