n=int(input("How many words"))
print ("Enter")
li=[]
for i in range(n):
    li.append(input())
num=int(input("Enter the value"))
def filter_longer_words(li):
    l2=[]
    for x in li:
        if len(x)>num:
            do=lambda x:l2.append(x)
            do(x)
    return l2
list1=filter_longer_words(li)
print (list1)
