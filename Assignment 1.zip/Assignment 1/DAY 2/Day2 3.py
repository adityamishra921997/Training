n=int(input('enter the size of list'))
l=[]
print('enter the words')
for i in range(0,n):
    l.append (input(''))
for i in l:
    print(i , len(i))
