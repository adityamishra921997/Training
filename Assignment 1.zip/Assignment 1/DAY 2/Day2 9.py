def char_freq(s):
    temp="abcgbcrtgbcsddfkmn"
    for i in temp :
        if i in s :
            print(i,s.count(i))
s=input('enter the string')
char_freq(s)
