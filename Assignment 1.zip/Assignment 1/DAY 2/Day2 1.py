def generate_n_char(n,c):
    for i in range(0,n):
        print(c, end='')

n=int(input('enter the integer :'))
c=input('enter the character :')
generate_n_char(n,c)
