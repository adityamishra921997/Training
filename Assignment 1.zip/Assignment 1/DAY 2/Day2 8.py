def translate(s):
    st=s.replace("merry","god").replace ("christmas","jul").replace ("and","och").replace ("happy","gott").replace ("new","nytt").replace ("year","år")
    print(st)

a=input('enter the string')
translate(a)
